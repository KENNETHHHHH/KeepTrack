# NodeJSPassportAuth

1. Clone the Repo.
2. Go into the folder and hit the npm install command
3. Start the mongodb server.
4. Run the command: npm start
